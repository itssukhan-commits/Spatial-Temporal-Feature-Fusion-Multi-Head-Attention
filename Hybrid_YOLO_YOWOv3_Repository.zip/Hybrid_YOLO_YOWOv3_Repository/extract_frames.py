"""Decode original videos to zero-based JPEG frames required by the annotation manifests."""
import argparse
import json
from pathlib import Path
import cv2
import pandas as pd
from runtime import sha256,write_json


def main():
    p=argparse.ArgumentParser();p.add_argument('--video-map',required=True,help='JSON {video_id: original video filepath}')
    p.add_argument('--annotations',nargs='+',required=True);p.add_argument('--frames-root',required=True)
    p.add_argument('--clip-length',type=int,default=32,help='Use 32 to support all context-length experiments')
    p.add_argument('--overwrite',action='store_true');a=p.parse_args()
    mapping=json.loads(Path(a.video_map).read_text());df=pd.concat([pd.read_csv(x) for x in a.annotations]);root=Path(a.frames_root).resolve();records=[]
    for video,rows in df.groupby('video_id'):
        directory=(root/video).resolve()
        if not directory.is_relative_to(root):raise ValueError('video_id escapes frame root')
        directory.mkdir(parents=True,exist_ok=True)
        if video not in mapping:raise KeyError(f'Missing video mapping: {video}')
        required=set()
        for key in rows.frame_idx.unique():required.update(range(max(0,int(key)-a.clip_length+1),int(key)+1))
        if not required:continue
        cap=cv2.VideoCapture(mapping[video]);index=0;written=0
        if not cap.isOpened():raise ValueError(f'Cannot open video {video}')
        try:
            while index<=max(required):
                ok,frame=cap.read()
                if not ok:raise ValueError(f'Video {video} ends before required frame {index}')
                if index in required:
                    target=directory/f'{index:05d}.jpg'
                    if target.exists() and not a.overwrite:raise FileExistsError(f'Frame exists; do not mix extraction versions: {target}')
                    if not cv2.imwrite(str(target),frame,[cv2.IMWRITE_JPEG_QUALITY,95]):raise IOError(f'Cannot write {target}')
                    written+=1
                index+=1
        finally:cap.release()
        records.append({'video_id':video,'original_video_sha256':sha256(mapping[video]),'frames_written':written,
                        'index_base':0,'JPEG_quality':95,'color_file_format':'BGR encoding; loader converts RGB'})
    write_json(root/'extraction_provenance.json',records)


if __name__=='__main__':main()
