"""
Loss functions matching the manuscript's "Optimization Objective" subsection:

    L_cls  = -1/N sum [y_i log(y_hat_i) + (1-y_i) log(1 - y_hat_i)]   (BCE)
    L_box  = 1 - IoU(B, B_hat)
    L_conf = BCE(S, S_hat)
    L_total = L_cls + lambda_1 * L_box + lambda_2 * L_conf

Label assignment: one regression target per cell containing a ground-truth
box center. Later boxes overwrite regression coordinates on collisions;
classification labels accumulate at that cell. This is not FCOS center sampling.
"""
from typing import List, Dict
import torch
import torch.nn.functional as F

from utils import box_iou_xywh


def assign_targets(boxes: List[torch.Tensor], grid_h: int, grid_w: int,
                    num_classes: int, device) -> Dict[str, torch.Tensor]:
    """
    boxes: list (len=batch) of [num_boxes_i, 5] tensors (cls, x, y, w, h), normalized [0,1]
    Returns dense per-cell targets of shape [B, grid_h, grid_w, ...]
    """
    B = len(boxes)
    cls_target = torch.zeros(B, num_classes, grid_h, grid_w, device=device)
    box_target = torch.zeros(B, 4, grid_h, grid_w, device=device)
    conf_target = torch.zeros(B, 1, grid_h, grid_w, device=device)
    pos_mask = torch.zeros(B, grid_h, grid_w, dtype=torch.bool, device=device)

    for b in range(B):
        gt = boxes[b]
        if gt.numel() == 0:
            continue
        gt = gt.to(device)
        for row in gt:
            c, x, y, w, h = row.tolist()
            c = int(c)
            # grid cell containing the box center
            gi = min(int(x * grid_w), grid_w - 1)
            gj = min(int(y * grid_h), grid_h - 1)

            cls_target[b, c, gj, gi] = 1.0
            box_target[b, :, gj, gi] = torch.tensor([x, y, w, h], device=device)
            conf_target[b, 0, gj, gi] = 1.0
            pos_mask[b, gj, gi] = True

    return {
        "cls_target": cls_target,
        "box_target": box_target,
        "conf_target": conf_target,
        "pos_mask": pos_mask,
    }


def hybrid_loss(preds: Dict[str, torch.Tensor], boxes: List[torch.Tensor],
                 num_classes: int, lambda_box: float = 5.0, lambda_conf: float = 1.0):
    """
    preds: dict with 'cls_logits' [B,C,H,W], 'reg' [B,4,H,W], 'conf_logits' [B,1,H,W]
    boxes: list of [num_boxes_i, 5] ground-truth tensors per sample
    """
    device = preds["cls_logits"].device
    B, C, H, W = preds["cls_logits"].shape

    targets = assign_targets(boxes, H, W, num_classes, device)

    # ---- L_cls : binary cross-entropy over the full classification map ----
    l_cls = F.binary_cross_entropy_with_logits(
        preds["cls_logits"], targets["cls_target"], reduction="mean"
    )

    # ---- L_box : 1 - IoU(B, B_hat), computed only at positive cells ----
    pos_mask = targets["pos_mask"]  # [B,H,W]
    num_pos = pos_mask.sum().clamp(min=1)

    pred_box = preds["reg"].sigmoid()  # keep predictions in [0,1] normalized space
    pred_box_pos = pred_box.permute(0, 2, 3, 1)[pos_mask]     # [num_pos, 4]
    gt_box_pos = targets["box_target"].permute(0, 2, 3, 1)[pos_mask]  # [num_pos, 4]

    if pred_box_pos.numel() > 0:
        ious = box_iou_xywh(pred_box_pos, gt_box_pos).diagonal()
        l_box = (1.0 - ious).sum() / num_pos
    else:
        l_box = torch.tensor(0.0, device=device)

    # ---- L_conf : BCE(S, S_hat) over the full confidence map ----
    l_conf = F.binary_cross_entropy_with_logits(
        preds["conf_logits"], targets["conf_target"], reduction="mean"
    )

    l_total = l_cls + lambda_box * l_box + lambda_conf * l_conf

    return {
        "loss": l_total,
        "loss_cls": l_cls.detach(),
        "loss_box": l_box.detach() if torch.is_tensor(l_box) else torch.tensor(l_box),
        "loss_conf": l_conf.detach(),
    }
