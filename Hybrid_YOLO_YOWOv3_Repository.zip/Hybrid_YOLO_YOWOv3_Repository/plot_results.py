"""Generate manuscript charts only from executed histories, predictions and profiling records."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from runtime import write_json

COLORS=['#1769D2','#009DA6','#7751C9']


def main():
    p=argparse.ArgumentParser();p.add_argument('--runs',default='runs');p.add_argument('--output',default='runs/figures');a=p.parse_args()
    root=Path(a.runs);out=Path(a.output);out.mkdir(parents=True,exist_ok=True);status={}
    ref=root/'complete_T16_seed42'
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    def save(number,fig):
        fig.tight_layout();fig.savefig(out/f'Figure{number}.PNG',dpi=300,bbox_inches='tight');plt.close(fig);status[f'Figure{number}']='generated from execution records'
    def bars(number,title,labels,values,ylabel='Score (%)'):
        fig,ax=plt.subplots(figsize=(10,6));patch=ax.bar(labels,values,color=[COLORS[i%3] for i in range(len(values))]);ax.set_ylim(0,100)
        ax.bar_label(patch,fmt='%.2f');ax.set_title(title);ax.set_ylabel(ylabel);save(number,fig)
    hist=ref/'history.csv'
    if hist.exists():
        h=pd.read_csv(hist);fig,axes=plt.subplots(2,1,figsize=(10,7),sharex=True)
        for col,label,color in [('train_loss','Training',COLORS[0]),('val_loss','Validation',COLORS[1])]:axes[0].plot(h.epoch,h[col],label=label,color=color)
        best=h.loc[h.val_loss.idxmin()];axes[0].axvline(best.epoch,ls='--',color=COLORS[2],label=f'Validation-selected epoch {int(best.epoch)}')
        axes[0].set_ylabel('Mean mini-batch loss');axes[0].legend();axes[1].step(h.epoch,h.learning_rate,where='post');axes[1].set_ylabel('Learning rate');axes[1].set_xlabel('Epoch');save(5,fig)
    result=ref/'evaluation/results.json'
    if result.exists():
        r=json.loads(result.read_text());bars(6,'Aggregate key-frame localization: reference run',['Precision','Recall','mAP@0.5'],[r['precision'],r['recall'],r['mAP50']])
        bars(11,'Class-wise AP at IoU 0.5',[x['class'] for x in r['per_class']],[x['AP50'] for x in r['per_class']])
        errors=r['fp_categories'];fig,ax=plt.subplots(figsize=(11,6));labels=list(errors);values=[errors[x] for x in labels]
        ax.barh([x.replace('_',' ') for x in labels],values,color=COLORS[0]);ax.set_xlabel('False-positive count');ax.set_title(f'Reference-run false-positive counts (total {sum(values)})');save(12,fig)
    sweep=ref/'analysis/threshold_sweep.json'
    if sweep.exists():
        rs=json.loads(sweep.read_text());fig,ax=plt.subplots(figsize=(10,6))
        for key,color in zip(['precision','recall','f1'],COLORS):ax.plot([x['confidence'] for x in rs],[x[key] for x in rs],marker='o',label=key,color=color)
        ax.set(xlabel='Confidence threshold',ylabel='Score (%)',ylim=(0,100),title='Fixed-checkpoint threshold sweep');ax.legend();save(7,fig)
    profile=ref/'profiling/profiling.json'
    if profile.exists():
        pr=json.loads(profile.read_text());s=pr['offline_serial'];fig,ax=plt.subplots(figsize=(12,6))
        ax.barh(s['stage_names'],s['stage_mean_ms'],color=COLORS[0]);ax.set_xlabel('Mean duration (ms)')
        ax.set_title('Measured serial JPEG-frame pipeline latency')
        fig.text(.5,.01,f"Total: {s['total_mean_ms']:.2f} ms; {s['key_frames_per_second']:.2f} key frames/s. Live acquisition and queueing excluded.",ha='center',fontsize=9)
        save(9,fig)
    variant_labels=['spatial_only','temporal_only','fusion_no_attention','complete'];variant_results=[]
    for v in variant_labels:
        file=root/f'{v}_T16_seed42/evaluation/results.json'
        if file.exists():variant_results.append(json.loads(file.read_text()))
    if len(variant_results)==4:bars(10,'Component comparison results',[v.replace('_','\n') for v in variant_labels],[r['mAP50'] for r in variant_results],'mAP@0.5 (%)')
    seeds=[]
    for seed in [21,42,84]:
        file=root/f'complete_T16_seed{seed}/evaluation/results.json'
        if file.exists():seeds.append((seed,json.loads(file.read_text())))
    if len(seeds)==3:
        fig,axes=plt.subplots(1,3,figsize=(12,5));stats={}
        for ax,key,color in zip(axes,['precision','recall','mAP50'],COLORS):
            values=[r[key] for _,r in seeds];ax.plot([s for s,_ in seeds],values,marker='o',color=color);ax.axhline(np.mean(values),ls='--',color=color)
            stats[key]={'mean':float(np.mean(values)),'sample_sd':float(np.std(values,ddof=1))}
            ax.set(xlabel='Initialization seed',ylabel='Score (%)',title=f'{key}: SD={np.std(values,ddof=1):.2f} pp',ylim=(0,100))
        save(13,fig);write_json(out/'seed_statistics.json',stats)
    clip_results=[]
    for length in [8,16,32]:
        file=root/f'complete_T{length}_seed42/evaluation/results.json'
        if file.exists():clip_results.append((length,json.loads(file.read_text())))
    if len(clip_results)==3:bars(14,'Retrained clip-length comparisons',[str(x) for x,_ in clip_results],[r['mAP50'] for _,r in clip_results],'mAP@0.5 (%)')
    boot=ref/'analysis/bootstrap.json'
    if boot.exists() and result.exists():
        b=json.loads(boot.read_text());r=json.loads(result.read_text());fig,ax=plt.subplots(figsize=(10,5))
        for i,(key,color) in enumerate(zip(['precision','recall','mAP50'],COLORS)):
            lo,hi=b['percentile_intervals'][key];ax.hlines(i,lo,hi,color=color,lw=3);ax.plot(r[key],i,'o',color=color)
        ax.set_yticks(range(3),['Precision','Recall','mAP@0.5']);ax.set(xlabel='Score (%)',xlim=(0,100),title='Video-cluster bootstrap: percentile 95% intervals');save(15,fig)
    for number in [5,6,7,9,10,11,12,13,14,15]:
        status.setdefault(f'Figure{number}','not generated: required execution records unavailable')
    write_json(out/'figure_manifest.json',status);print(status)


if __name__=='__main__':main()
