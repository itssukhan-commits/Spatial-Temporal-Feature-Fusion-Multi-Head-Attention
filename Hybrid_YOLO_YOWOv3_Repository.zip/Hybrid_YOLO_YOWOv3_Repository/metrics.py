"""
Evaluation metrics matching the manuscript's "Evaluation Metrics" subsection:

    Precision = TP / (TP + FP)
    Recall    = TP / (TP + FN)
    F1        = 2 * Precision * Recall / (Precision + Recall)
    mAP       = (1/N) * sum_i AP_i

Detections and ground truths are matched per-image using IoU >= iou_threshold,
using the manuscript-specific highest-IoU same-class matcher. Already
matched highest-IoU targets are rejected without reassignment. AP uses all-point
interpolation, not COCO 101-point AP.
"""
from typing import List, Dict
import numpy as np
import torch

from utils import box_iou_xywh


def decode_predictions(cls_logits, reg, conf_logits, score_threshold=0.3):
    """
    Converts a single sample's dense prediction maps into a flat list of
    (cls, score, x, y, w, h) detections in normalized image coordinates.
    """
    C, H, W = cls_logits.shape
    cls_probs = cls_logits.sigmoid()      # [C,H,W]
    conf_probs = conf_logits.sigmoid()    # [1,H,W]
    box = reg.sigmoid()                    # [4,H,W], already (x,y,w,h) normalized

    scores, class_ids = cls_probs.max(dim=0)   # [H,W] each
    scores = scores * conf_probs[0]             # combine class score with objectness

    dets = []
    ys, xs = torch.where(scores >= score_threshold)
    for gy, gx in zip(ys.tolist(), xs.tolist()):
        dets.append({
            "grid_y": gy, "grid_x": gx,
            "cls": int(class_ids[gy, gx].item()),
            "score": float(scores[gy, gx].item()),
            "box": box[:, gy, gx].tolist(),   # (x, y, w, h)
        })
    return dets


def match_detections_to_gt(dets: List[Dict], gts: np.ndarray, iou_threshold: float = 0.5):
    """
    dets: list of {'cls','score','box'} for one image, SORTED by score descending
    gts:  [num_gt, 5] array (cls, x, y, w, h) for the same image
    Returns per-detection tp/fp flags (1/0) aligned with `dets` order.
    """
    matched_gt = set()
    tp = np.zeros(len(dets))
    fp = np.zeros(len(dets))

    if len(gts) == 0:
        fp[:] = 1
        return tp, fp

    gt_boxes = torch.tensor(gts[:, 1:], dtype=torch.float32)
    gt_classes = gts[:, 0].astype(int)

    for i, det in enumerate(dets):
        det_box = torch.tensor([det["box"]], dtype=torch.float32)
        same_cls_idx = np.where(gt_classes == det["cls"])[0]
        if len(same_cls_idx) == 0:
            fp[i] = 1
            continue
        ious = box_iou_xywh(det_box, gt_boxes[same_cls_idx]).squeeze(0)
        best_iou, best_local = ious.max(0)
        best_idx = same_cls_idx[best_local.item()]
        if best_iou.item() >= iou_threshold and best_idx not in matched_gt:
            tp[i] = 1
            matched_gt.add(best_idx)
        else:
            fp[i] = 1
    return tp, fp


def compute_precision_recall_f1(all_dets: List[List[Dict]], all_gts: List[np.ndarray],
                                 iou_threshold: float = 0.5):
    """
    all_dets: list (len=num_images) of detection lists
    all_gts:  list (len=num_images) of [num_gt_i, 5] arrays
    """
    total_tp, total_fp, total_gt = 0, 0, 0
    for dets, gts in zip(all_dets, all_gts):
        dets_sorted = sorted(dets, key=lambda d: -d["score"])
        tp, fp = match_detections_to_gt(dets_sorted, gts, iou_threshold)
        total_tp += tp.sum()
        total_fp += fp.sum()
        total_gt += len(gts)

    precision = total_tp / max(total_tp + total_fp, 1e-9)
    recall = total_tp / max(total_gt, 1e-9)
    f1 = 2 * precision * recall / max(precision + recall, 1e-9)
    return float(precision), float(recall), float(f1)


def compute_ap_per_class(all_dets: List[List[Dict]], all_gts: List[np.ndarray],
                          cls_id: int, iou_threshold: float = 0.5) -> float:
    """All-point interpolated average precision for one class."""
    scored = []   # (score, tp, fp) per detection, across all images
    num_gt_total = 0

    for img_idx, (dets, gts) in enumerate(zip(all_dets, all_gts)):
        cls_dets = [d for d in dets if d["cls"] == cls_id]
        cls_dets = sorted(cls_dets, key=lambda d: -d["score"])
        cls_gts = gts[gts[:, 0] == cls_id] if len(gts) > 0 else np.zeros((0, 5))
        num_gt_total += len(cls_gts)

        tp, fp = match_detections_to_gt(cls_dets, cls_gts, iou_threshold)
        for d, t, f in zip(cls_dets, tp, fp):
            scored.append((d["score"], t, f))

    if num_gt_total == 0 or len(scored) == 0:
        return 0.0

    scored.sort(key=lambda s: -s[0])
    tp_cum = np.cumsum([s[1] for s in scored])
    fp_cum = np.cumsum([s[2] for s in scored])

    recalls = tp_cum / max(num_gt_total, 1e-9)
    precisions = tp_cum / np.maximum(tp_cum + fp_cum, 1e-9)

    # all-point interpolation
    mrec = np.concatenate(([0.0], recalls, [1.0]))
    mpre = np.concatenate(([1.0], precisions, [0.0]))
    for i in range(len(mpre) - 2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i + 1])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    ap = np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1])
    return float(ap)


def compute_map(all_dets: List[List[Dict]], all_gts: List[np.ndarray],
                 num_classes: int, iou_threshold: float = 0.5) -> float:
    """mAP = (1/N) * sum_i AP_i, over all configured classes; absent classes receive zero AP."""
    aps = []
    present_classes = set()
    for gts in all_gts:
        if len(gts) > 0:
            present_classes.update(gts[:, 0].astype(int).tolist())

    for c in range(num_classes):
        aps.append(compute_ap_per_class(all_dets, all_gts, c, iou_threshold))

    return float(np.mean(aps)) if aps else 0.0
