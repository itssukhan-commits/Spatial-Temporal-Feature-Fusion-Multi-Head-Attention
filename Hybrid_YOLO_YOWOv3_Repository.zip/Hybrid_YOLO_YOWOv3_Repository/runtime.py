"""Shared device selection, provenance, JSON and model initialization."""
import hashlib
import json
import platform
import sys
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')


def resolve_device(cfg):
    import torch
    device = torch.device(cfg['hardware']['device'])
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA was requested but is unavailable. For a CPU smoke test explicitly set hardware.device: cpu.')
    return device


def environment(device=None):
    import torch
    packages = {}
    for name in ['torch', 'torchvision', 'ultralytics', 'thop', 'numpy', 'pandas', 'opencv-python', 'PyYAML']:
        try: packages[name] = version(name)
        except PackageNotFoundError: packages[name] = None
    return {'python': sys.version, 'platform': platform.platform(), 'packages': packages,
            'torch_cuda_build': torch.version.cuda, 'device': str(device),
            'cudnn_version': torch.backends.cudnn.version(),
            'gpu': torch.cuda.get_device_name(device) if device and device.type == 'cuda' else None}


def initialize(model, cfg, device, trace_path=None):
    import torch
    size = cfg['data']['img_size']; length = cfg['data']['clip_len']
    shapes, handles = {}, []
    def capture(name):
        def hook(module, inputs, output):
            if isinstance(output, torch.Tensor): shapes[name] = list(output.shape)
            elif isinstance(output, dict): shapes[name] = {k: list(v.shape) for k, v in output.items()}
        return hook
    for name, module in model.named_modules():
        if name and any(name == prefix or name == prefix + '.channel_proj' or name == prefix + '.backbone'
                        for prefix in ['spatial_branch', 'temporal_branch', 'fusion', 'attn_refine', 'detect_head']):
            handles.append(module.register_forward_hook(capture(name)))
    model.eval()
    with torch.no_grad():
        outputs = model(torch.zeros(1, 3, length, size, size, device=device),
                        torch.zeros(1, 3, size, size, device=device))
    for handle in handles: handle.remove()
    shapes['outputs'] = {k: list(v.shape) for k, v in outputs.items()}
    shapes['inputs'] = {'clip': [1, 3, length, size, size], 'key_frame': [1, 3, size, size]}
    initialization = {}
    for name in ['spatial_branch', 'temporal_branch']:
        branch = getattr(model, name, None)
        path = getattr(branch, 'pretrained_weight_path', None)
        initialization[name] = {'pretrained_weight_path': str(path) if path else None,
                                'sha256': sha256(path) if path and Path(path).is_file() else None,
                                'upstream_url': getattr(branch, 'pretrained_weights_url', None)}
    shapes['pretrained_initialization'] = initialization
    if trace_path: write_json(trace_path, shapes)
    return shapes


def load_selected(cfg, checkpoint, device):
    import torch
    from model import build_model
    ckpt = torch.load(checkpoint, map_location=device, weights_only=True)
    saved = ckpt.get('config')
    if saved:
        for section, keys in [('model', ['variant', 'spatial_backbone', 'temporal_backbone', 'inter_channels', 'fusion_channels', 'attn_heads']),
                              ('data', ['clip_len', 'img_size', 'num_classes', 'class_names'])]:
            for key in keys:
                if saved[section].get(key) != cfg[section].get(key):
                    raise ValueError(f'Checkpoint/config mismatch: {section}.{key}')
    model = build_model(cfg, pretrained=False).to(device)
    initialize(model, cfg, device)
    model.load_state_dict(ckpt['model_state'], strict=True)
    return model.eval(), ckpt
