"""Optional dependency-backed smoke checks; no pretrained downloads or research measurements."""
import importlib.util
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
READY=all(importlib.util.find_spec(x) is not None for x in ['torch','torchvision','ultralytics'])


@unittest.skipUnless(READY,'PyTorch/torchvision/Ultralytics not installed')
class ModelTests(unittest.TestCase):
    def test_variants_and_empty_ground_truth_loss(self):
        import torch
        from model import HybridYOLOYOWOv3
        from losses import hybrid_loss
        torch.set_num_threads(2)
        for variant in ['complete','fusion_no_attention','spatial_only','temporal_only']:
            model=HybridYOLOYOWOv3(6,pretrained=False,variant=variant).eval()
            with torch.no_grad():out=model(torch.zeros(1,3,8,64,64),torch.zeros(1,3,64,64))
            self.assertEqual(out['cls_logits'].shape[1],6)
            loss=hybrid_loss(out,[torch.empty(0,5)],6)
            self.assertTrue(torch.isfinite(loss['loss']).item())
            self.assertEqual(loss['loss_box'].item(),0.)
            del model


if __name__=='__main__':unittest.main()
