import unittest
import tempfile
from pathlib import Path
import sys
import pandas as pd
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analysis import match,summarize,bootstrap,nms
from audit_dataset import validate_annotations,audit


def det(c=0,score=.9,box=None):return {'cls':c,'score':score,'box':box or [.5,.5,.4,.4]}


class ProtocolTests(unittest.TestCase):
    def test_duplicate_wrong_class_and_negative_frames(self):
        gt=[[0,.5,.5,.4,.4]]
        rows,missing=match([det(),det(score=.8),det(1,.7)],gt)
        self.assertEqual([x['category'] for x in rows],['true_positive','duplicate_or_assignment_conflict','wrong_class'])
        self.assertEqual(missing,[])
        result,_=summarize([{'video_id':'a','frame_idx':0,'detections':[det(),det(score=.8),det(1,.7)],'ground_truth':gt},
                            {'video_id':'b','frame_idx':0,'detections':[det()],'ground_truth':[]}])
        self.assertEqual((result['TP'],result['FP'],result['FN']),(1,3,0))
        self.assertAlmostEqual(result['precision'],25.)
        self.assertAlmostEqual(result['mAP50'],100/6)
    def test_highest_iou_target_is_not_reassigned(self):
        gt=[[0,.5,.5,.4,.4],[0,.55,.5,.4,.4]]
        rows,missing=match([det(),det(score=.8)],gt)
        self.assertEqual(sum(r['tp'] for r in rows),1)
        self.assertEqual(missing,[1])
    def test_confidence_is_separate_from_ap_floor(self):
        r={'video_id':'a','frame_idx':0,'detections':[det(score=.2)],'ground_truth':[[0,.5,.5,.4,.4]]}
        s,_=summarize([r]);self.assertEqual(s['TP'],0);self.assertEqual(s['FN'],1)
        self.assertAlmostEqual(s['mAP50'],100/6)
    def test_nms_class_aware(self):
        self.assertEqual(len(nms([det(),det(score=.8),det(1,.7)])),2)
    def test_bootstrap_multiplicity_matches_explicit_replication(self):
        records=[{'video_id':'a','frame_idx':0,'detections':[det()],'ground_truth':[[0,.5,.5,.4,.4]]},
                 {'video_id':'b','frame_idx':0,'detections':[],'ground_truth':[[0,.5,.5,.4,.4]]}]
        seed=7;n=12;actual=bootstrap(records,n,seed);rng=np.random.default_rng(seed)
        expected=[]
        for _ in range(n):
            selected=rng.integers(0,2,2);s,_=summarize([records[int(i)] for i in selected]);expected.append([s['precision'],s['recall'],s['mAP50']])
        np.testing.assert_allclose(actual['replicate_values'],expected)
    def test_annotation_sentinel_and_bounds(self):
        columns=['video_id','frame_idx','cls','x','y','w','h','t']
        valid=pd.DataFrame([['a',0,0,.5,.5,.4,.4,1],['a',1,-1,0,0,0,0,0]],columns=columns)
        validate_annotations(valid,'/tmp/frames')
        invalid=valid.copy();invalid.loc[0,'w']=2
        with self.assertRaises(ValueError):validate_annotations(invalid,'/tmp/frames')
        mixed=pd.concat([valid,valid.iloc[[0]].assign(frame_idx=1)])
        with self.assertRaises(ValueError):validate_annotations(mixed,'/tmp/frames')
    def test_video_split_leakage(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);csv=root/'shared.csv'
            pd.DataFrame([['same',0,-1,0,0,0,0,0]],columns=['video_id','frame_idx','cls','x','y','w','h','t']).to_csv(csv,index=False)
            cfg={'data':{'frames_root':str(root),'num_classes':6,'class_names':['a','b','c','d','e','f'],
                         **{s+'_csv':str(csv) for s in ['train','val','test']}}}
            with self.assertRaises(ValueError):audit(cfg,False)


if __name__=='__main__':unittest.main()
