"""Explicit CSV adaptation; does not infer native dataset formats or split assignments."""
import argparse
import json
from pathlib import Path
import pandas as pd
from audit_dataset import validate_annotations


def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--frames-root',required=True);p.add_argument('--mapping',help='JSON mapping canonical column name -> input column name')
    p.add_argument('--coordinates',choices=['normalized-xywh','pixel-xyxy'],required=True)
    p.add_argument('--frame-base',type=int,choices=[0,1],required=True);a=p.parse_args()
    df=pd.read_csv(a.input)
    if a.mapping:
        mapping=json.loads(Path(a.mapping).read_text());df=df.rename(columns={value:key for key,value in mapping.items()})
    df['frame_idx']=df['frame_idx']-a.frame_base
    if a.coordinates=='pixel-xyxy':
        required={'xmin','ymin','xmax','ymax','image_width','image_height'}
        if not required<=set(df):raise ValueError('Pixel conversion requires explicit xmin,ymin,xmax,ymax,image_width,image_height columns')
        if (df[['image_width','image_height']]<=0).any().any():raise ValueError('Invalid original dimensions')
        df['x']=(df.xmin+df.xmax)/(2*df.image_width);df['y']=(df.ymin+df.ymax)/(2*df.image_height)
        df['w']=(df.xmax-df.xmin)/df.image_width;df['h']=(df.ymax-df.ymin)/df.image_height
        neg=df.cls==-1;df.loc[neg,['x','y','w','h']]=0
    validate_annotations(df,a.frames_root,6)
    from audit_dataset import COLUMNS
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);df[COLUMNS].to_csv(out,index=False);print(out)


if __name__=='__main__':main()
