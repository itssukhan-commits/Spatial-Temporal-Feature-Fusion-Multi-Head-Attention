"""Figure 8: render original source frames with their record-derived boxes and outcomes."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import cv2
from analysis import NAMES, summarize
from audit_dataset import frame_path
from runtime import write_json, sha256


def main():
    p=argparse.ArgumentParser();p.add_argument('--predictions',required=True);p.add_argument('--frames-root',required=True)
    p.add_argument('--selection',help='JSON list of {video_id,frame_idx}; without this, select observed outcome categories')
    p.add_argument('--output',default='runs/figures/Figure8.PNG');p.add_argument('--confidence',type=float,default=.3)
    a=p.parse_args();records=json.loads(Path(a.predictions).read_text());_,outcomes=summarize(records,a.confidence)
    if a.selection:
        requested=json.loads(Path(a.selection).read_text());index={(r['video_id'],r['frame_idx']):r for r in outcomes}
        chosen=[index[(r['video_id'],r['frame_idx'])] for r in requested]
    else:
        chosen=[];used=set()
        for category in ['true_positive','insufficient_overlap','miss','duplicate_or_assignment_conflict','wrong_class','background_or_negligible_overlap']:
            for r in outcomes:
                key=(r['video_id'],r['frame_idx'])
                exists=bool(r['unmatched_gt_indices']) if category=='miss' else any(m['category']==category for m in r['matching'])
                if key not in used and exists:chosen.append(r);used.add(key);break
    if not chosen:raise ValueError('No matching examples available')
    cols=3;rows=(len(chosen)+cols-1)//cols;fig,axes=plt.subplots(rows,cols,figsize=(15,5*rows),squeeze=False)
    sources=[]
    for ax,r in zip(axes.flat,chosen):
        path=frame_path(a.frames_root,r['video_id'],r['frame_idx']);image=cv2.imread(str(path))
        if image is None:raise ValueError(f'Unreadable source: {path}')
        image=cv2.cvtColor(image,cv2.COLOR_BGR2RGB);height,width=image.shape[:2];ax.imshow(image)
        for c,x,y,w,h in r['ground_truth']:
            ax.add_patch(Rectangle(((x-w/2)*width,(y-h/2)*height),w*width,h*height,fill=False,color='#338653',lw=2))
            ax.text((x-w/2)*width,(y-h/2)*height,'GT: '+NAMES[int(c)],color='white',fontsize=8,bbox={'facecolor':'#338653','alpha':.85})
        by_index={m['detection_index']:m for m in r['matching']}
        for i,d in enumerate(r['detections']):
            x,y,w,h=d['box'];m=by_index[i]
            ax.add_patch(Rectangle(((x-w/2)*width,(y-h/2)*height),w*width,h*height,fill=False,color='#2469B2',lw=2,ls='--'))
            label=f"Pred: {NAMES[d['cls']]} {d['score']:.2f}; same-class IoU {m['same_class_iou']:.2f}"
            ax.text((x-w/2)*width,(y+h/2)*height,label,color='white',fontsize=7,bbox={'facecolor':'#2469B2','alpha':.85})
        categories=sorted({m['category'] for m in r['matching']});text=', '.join(x.replace('_',' ') for x in categories)
        if r['unmatched_gt_indices']:text+=f"; missed GT: {len(r['unmatched_gt_indices'])}"
        ax.set_title(f"{r['video_id']} | frame {r['frame_idx']}\n{text}",fontsize=9);ax.axis('off')
        sources.append({**r,'source_frame_sha256':sha256(path)})
    for ax in list(axes.flat)[len(chosen):]:ax.axis('off')
    fig.suptitle('Ground-truth annotations and reference-run predictions',fontsize=16)
    fig.tight_layout(rect=(0,0,1,.95));out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(out,dpi=300,bbox_inches='tight');plt.close(fig)
    write_json(out.with_suffix('.records.json'),{'predictions_sha256':sha256(a.predictions),'confidence':a.confidence,
               'matching_iou':.5,'note':'Source pixels are read directly; same-class IoU does not represent overlap with a wrong-class target.','examples':sources})
    print(out)


if __name__=='__main__':main()
