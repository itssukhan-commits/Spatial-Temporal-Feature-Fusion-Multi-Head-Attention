"""FP32 evaluation with checkpoint-linked predictions and measured localization summaries."""
import argparse
from pathlib import Path
import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm
from dataset import AnomalyClipDataset, collate_fn
from metrics import decode_predictions
from analysis import summarize
from audit_dataset import audit
from runtime import resolve_device, load_selected, write_json, sha256, environment, initialize


def main():
    p=argparse.ArgumentParser();p.add_argument('--config',default='configs/config.yaml');p.add_argument('--checkpoint',required=True)
    p.add_argument('--output',default='runs/reference/evaluation');a=p.parse_args()
    cfg=yaml.safe_load(Path(a.config).read_text());device=resolve_device(cfg)
    audit(cfg,check_frames=True)
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    model,ckpt=load_selected(cfg,a.checkpoint,device)
    initialize(model,cfg,device,out/'tensor_shapes.json')
    ds=AnomalyClipDataset(cfg['data']['test_csv'],cfg['data']['frames_root'],cfg['data']['clip_len'],
                          cfg['data']['img_size'],cfg['data']['num_classes'],False)
    loader=DataLoader(ds,batch_size=1,shuffle=False,num_workers=cfg['train']['num_workers'],collate_fn=collate_fn)
    records=[]
    with torch.inference_mode():
        for batch in tqdm(loader,desc='Test evaluation'):
            outputs=model(batch['clips'].to(device),batch['key_frames'].to(device))
            detections=decode_predictions(outputs['cls_logits'][0],outputs['reg'][0],outputs['conf_logits'][0],cfg['eval']['ap_score_floor'])
            records.append({'video_id':batch['video_ids'][0],'frame_idx':int(batch['frame_idxs'][0]),
                            'detections':detections,'ground_truth':batch['boxes'][0].tolist()})
    predictions=out/'predictions.json';write_json(predictions,records)
    summary,outcomes=summarize(records,cfg['eval']['score_threshold'],cfg['eval']['iou_threshold'],cfg['eval']['ap_score_floor'])
    summary['provenance']={'checkpoint_sha256':sha256(a.checkpoint),'predictions_sha256':sha256(predictions),
                           'test_csv_sha256':sha256(cfg['data']['test_csv']),'config_sha256':sha256(a.config),
                           'checkpoint_epoch':ckpt.get('epoch'),'seed':cfg['train']['seed'],
                           'variant':cfg['model']['variant'],'clip_length':cfg['data']['clip_len'],
                           'matching':'highest-IoU same-class; no reassignment','ap':'all-point interpolation',
                           'precision':'FP32','checkpoint_selection':'minimum validation mean mini-batch loss'}
    write_json(out/'results.json',summary);write_json(out/'matching_records.json',outcomes)
    write_json(out/'per_class.json',summary['per_class']);write_json(out/'environment.json',environment(device))
    print({k:summary[k] for k in ['precision','recall','f1','mAP50','GT','TP','FP','FN']})


if __name__=='__main__':main()
