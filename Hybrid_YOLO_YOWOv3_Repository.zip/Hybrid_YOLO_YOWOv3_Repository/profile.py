"""Synchronized forward profiling and serial JPEG-frame pipeline timing; no live-video claim."""
import argparse
import copy
import json
import time
from pathlib import Path
import numpy as np
import torch
import yaml
from runtime import resolve_device, load_selected, initialize, environment, write_json, sha256
from audit_dataset import frame_path
from dataset import AnomalyClipDataset, collate_fn
from metrics import decode_predictions
from losses import hybrid_loss


def main():
    p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--checkpoint',required=True)
    p.add_argument('--output',default='runs/reference/profiling');p.add_argument('--iterations',type=int,default=100)
    p.add_argument('--warmup',type=int,default=10);a=p.parse_args()
    if a.iterations<1 or a.warmup<0:raise ValueError('Invalid iteration counts')
    cfg=yaml.safe_load(Path(a.config).read_text());device=resolve_device(cfg);out=Path(a.output)
    model,_=load_selected(cfg,a.checkpoint,device);initialize(model,cfg,device,out/'tensor_shapes.json')
    size=cfg['data']['img_size'];length=cfg['data']['clip_len']
    clip=torch.randn(1,3,length,size,size,device=device);frame=torch.randn(1,3,size,size,device=device)
    def sync():
        if device.type=='cuda':torch.cuda.synchronize(device)
    latencies=[]
    with torch.inference_mode():
        for _ in range(a.warmup):model(clip,frame)
        sync()
        if device.type=='cuda':torch.cuda.reset_peak_memory_stats(device)
        for _ in range(a.iterations):
            sync();start=time.perf_counter();model(clip,frame);sync()
            latencies.append(1000*(time.perf_counter()-start))
    memory=torch.cuda.max_memory_allocated(device)/1e9 if device.type=='cuda' else None
    mean=float(np.mean(latencies));parameters=sum(p.numel() for p in model.parameters() if p.requires_grad)
    ops=None;failure=None;counted=None
    try:
        from thop import profile
        counted=copy.deepcopy(model)
        macs,_=profile(counted,inputs=(clip,frame),verbose=False);ops=2*float(macs)/1e9
    except Exception as exc:failure=str(exc)
    finally:
        if counted is not None:del counted
    result={'environment':environment(device),'checkpoint_sha256':sha256(a.checkpoint),
        'trainable_parameters':parameters,'params_M':parameters/1e6,'THOP_accounted_GFLOPs':ops,
        'THOP_failure':failure,'THOP_complete_operation_count':False,
        'THOP_limitations':'Custom attention einsum QK/AV operations lack dedicated counting rules.',
        'forward':{'precision':'FP32','batch_size':1,'resident_synthetic_inputs':True,'warmup':a.warmup,
          'iterations':a.iterations,'latencies_ms':latencies,'mean_ms':mean,'key_frames_per_second':1000/mean,
          'peak_allocated_device_GB':memory,'input_shape':[1,3,length,size,size]},
        'excluded':['camera acquisition','frame waiting','networking','display','queueing','asynchronous overlap']}
    # Offline timing mirrors the actual dataset loader but exposes separate stage boundaries.
    import cv2
    ds=AnomalyClipDataset(cfg['data']['test_csv'],cfg['data']['frames_root'],length,size,6,False)
    serial=[]; sample_ids=[]
    with torch.inference_mode():
        for sample in ds.samples[:a.iterations]:
            sync();start=time.perf_counter()
            indices=[max(0,sample['frame_idx']-length+1+k) for k in range(length)]
            raw=[]
            for index in indices:
                image=cv2.imread(str(frame_path(cfg['data']['frames_root'],sample['video_id'],index)))
                if image is None:raise ValueError('Unreadable JPEG frame')
                raw.append(image)
            read_done=time.perf_counter()
            processed=[cv2.resize(cv2.cvtColor(image,cv2.COLOR_BGR2RGB),(size,size)) for image in raw]
            arr=(np.stack(processed).astype(np.float32)/255.-.45)/.225
            cpu_clip=torch.from_numpy(arr).permute(3,0,1,2).unsqueeze(0)
            cpu_frame=cpu_clip[:,:,-1];prep_done=time.perf_counter()
            gpu_clip=cpu_clip.to(device);gpu_frame=cpu_frame.to(device);sync();transfer_done=time.perf_counter()
            outputs=model(gpu_clip,gpu_frame);sync();forward_done=time.perf_counter()
            dets=decode_predictions(outputs['cls_logits'][0],outputs['reg'][0],outputs['conf_logits'][0],cfg['eval']['ap_score_floor'])
            json.dumps(dets);sync();end=time.perf_counter()
            serial.append([1000*(read_done-start),1000*(prep_done-read_done),1000*(transfer_done-prep_done),
                           1000*(forward_done-transfer_done),1000*(end-forward_done)])
            sample_ids.append({'video_id':sample['video_id'],'frame_idx':sample['frame_idx']})
    durations=np.asarray(serial);serial_mean=float(durations.sum(1).mean())
    result['offline_serial']={'input_source':'pre-extracted JPEG frame files; not compressed-video container decoding',
      'cache_state':'OS cache uncontrolled; potentially warm','samples':len(serial),'sample_ids':sample_ids,
      'stage_names':['JPEG read/decode and clip assembly','resize/RGB/normalization','host-to-device transfer',
                     'model forward','prediction decode and in-memory JSON serialization'],
      'per_sample_stage_ms':serial,'stage_mean_ms':durations.mean(0).tolist(),
      'total_mean_ms':serial_mean,'key_frames_per_second':1000/serial_mean,
      'output_disk_writing_included':False,'forward_stage_separate_from_resident_synthetic_profile':True}
    del clip,frame,gpu_clip,gpu_frame,outputs
    # Training scope uses actual annotation-backed clips and accumulation over two batches.
    if device.type=='cuda':
        torch.cuda.empty_cache();train_ds=AnomalyClipDataset(cfg['data']['train_csv'],cfg['data']['frames_root'],length,size,6,True)
        batch_size=cfg['train']['batch_size'];accum=cfg['train']['grad_accum_steps']
        if len(train_ds)<batch_size*accum:raise ValueError('Not enough real samples for the declared training memory scope')
        model.train();optimizer=torch.optim.AdamW(model.parameters(),lr=cfg['train']['learning_rate'],weight_decay=cfg['train']['weight_decay'])
        scaler=torch.cuda.amp.GradScaler(enabled=cfg['train']['amp']);optimizer.zero_grad(set_to_none=True)
        torch.cuda.reset_peak_memory_stats(device)
        for batch_index in range(accum):
            batch=collate_fn([train_ds[batch_index*batch_size+k] for k in range(batch_size)])
            x=batch['clips'].to(device);key=batch['key_frames'].to(device)
            with torch.cuda.amp.autocast(enabled=cfg['train']['amp']):
                predictions=model(x,key)
                loss=hybrid_loss(predictions,batch['boxes'],6,cfg['train']['lambda_box'],cfg['train']['lambda_conf'])['loss']/accum
            scaler.scale(loss).backward()
            del predictions,loss,x,key,batch
        scaler.step(optimizer);scaler.update();sync()
        result['training_memory']={'peak_allocated_device_GB':torch.cuda.max_memory_allocated(device)/1e9,
          'batch_size':batch_size,'accumulation':accum,'amp':cfg['train']['amp'],'real_training_clips':True,
          'scope':'two accumulated batches and first AdamW step; includes resident model, gradients and optimizer state'}
    else:result['training_memory']=None
    write_json(out/'profiling.json',result);print('Profiling saved:',out/'profiling.json')


if __name__=='__main__':main()
