"""Hybrid YOLOv8n spatial features and R3D-18 temporal features with attention.
Research implementation; not the official YOWOv3 baseline. Initialization errors fail explicitly."""
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Spatial branch (YOLO-based, matches phi_s in the manuscript)
# ---------------------------------------------------------------------------
class SpatialBranch(nn.Module):
    def __init__(self, backbone_name: str = "yolov8n", pretrained: bool = True,
                 out_channels: int = 256):
        super().__init__()
        self.out_channels = out_channels
        self._use_ultralytics = False

        try:
            from ultralytics import YOLO
            yolo = YOLO(f"{backbone_name}.pt" if pretrained else f"{backbone_name}.yaml")
            # Ultralytics stores the underlying nn.Module in .model; we keep
            # the backbone+neck layers and drop the Detect() head so we get
            # raw multi-scale feature maps instead of final predictions.
            self.pretrained_weight_path = getattr(yolo, "ckpt_path", None) if pretrained else None
            full_model = yolo.model.model  # nn.Sequential of all layers
            self.backbone = full_model[:-1]  # drop Detect head (last module)
            self._use_ultralytics = True
            # project whatever channel count the last kept layer outputs to
            # a fixed out_channels so the rest of the pipeline is backbone-agnostic
            self.channel_proj = nn.LazyConv2d(out_channels, kernel_size=1)
        except Exception as e:
            raise RuntimeError("YOLO initialization failed; no architecture fallback is permitted") from e

    def forward(self, key_frame: torch.Tensor) -> torch.Tensor:
        """key_frame: [B, 3, H, W] -> F_s: [B, out_channels, H', W']"""
        x, saved = key_frame, []
        for layer in self.backbone:
            if layer.f != -1:
                x = saved[layer.f] if isinstance(layer.f, int) else [x if j == -1 else saved[j] for j in layer.f]
            x = layer(x)
            saved.append(x)
        feat = x
        if isinstance(feat, (list, tuple)):
            feat = feat[-1]
        feat = self.channel_proj(feat)
        return feat


# ---------------------------------------------------------------------------
# Temporal branch (YOWOv3-inspired 3D backbone, matches phi_t)
# ---------------------------------------------------------------------------
class TemporalBranch(nn.Module):
    def __init__(self, backbone_name: str = "r3d_18", pretrained: bool = True,
                 out_channels: int = 256):
        super().__init__()
        from torchvision.models.video import r3d_18, R3D_18_Weights

        weights = R3D_18_Weights.DEFAULT if pretrained else None
        net = r3d_18(weights=weights)
        self.pretrained_weights_url = weights.url if weights is not None else None
        from pathlib import Path
        self.pretrained_weight_path = str(Path(torch.hub.get_dir()) / "checkpoints" / weights.url.rsplit("/", 1)[-1]) if weights is not None else None
        # drop avgpool + fc; keep spatio-temporal conv stack
        self.backbone = nn.Sequential(
            net.stem, net.layer1, net.layer2, net.layer3, net.layer4,
        )
        self.channel_proj = nn.Conv3d(512, out_channels, kernel_size=1)

    def forward(self, clip: torch.Tensor) -> torch.Tensor:
        """clip: [B, 3, T, H, W] -> F_t: [B, out_channels, H', W'] (temporal dim squeezed)"""
        feat = self.backbone(clip)             # [B, C, T', H', W']
        feat = self.channel_proj(feat)
        feat = feat.mean(dim=2)                # squeeze temporal dim -> [B, C, H', W']
        return feat


# ---------------------------------------------------------------------------
# Multimodal fusion module: F_c = Concat(F_s_hat, F_t_hat); F_fusion = Conv(sigma(F_c))
# ---------------------------------------------------------------------------
class FusionModule(nn.Module):
    def __init__(self, spatial_channels: int, temporal_channels: int, fusion_channels: int):
        super().__init__()
        self.proj_s = nn.Conv2d(spatial_channels, fusion_channels, kernel_size=1)   # P_s
        self.proj_t = nn.Conv2d(temporal_channels, fusion_channels, kernel_size=1)  # P_t
        self.fuse_conv = nn.Sequential(
            nn.Conv2d(fusion_channels * 2, fusion_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(fusion_channels),
            nn.SiLU(inplace=True),   # sigma(.)
        )

    def forward(self, f_s: torch.Tensor, f_t: torch.Tensor) -> torch.Tensor:
        f_s_hat = self.proj_s(f_s)
        f_t_hat = self.proj_t(f_t)
        # align spatial resolution (temporal branch may output a coarser map)
        if f_t_hat.shape[-2:] != f_s_hat.shape[-2:]:
            f_t_hat = F.interpolate(f_t_hat, size=f_s_hat.shape[-2:],
                                     mode="bilinear", align_corners=False)
        f_c = torch.cat([f_s_hat, f_t_hat], dim=1)   # Concat(F_s_hat, F_t_hat)
        f_fusion = self.fuse_conv(f_c)
        return f_fusion


# ---------------------------------------------------------------------------
# Attention-based refinement: A(F) = Softmax(QK^T/sqrt(d)) V ; F_r = F_fusion + A(F_fusion)
# ---------------------------------------------------------------------------
class SelfAttentionRefine(nn.Module):
    def __init__(self, channels: int, num_heads: int = 4):
        super().__init__()
        assert channels % num_heads == 0, "channels must be divisible by num_heads"
        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = channels // num_heads

        self.q_proj = nn.Conv2d(channels, channels, kernel_size=1)
        self.k_proj = nn.Conv2d(channels, channels, kernel_size=1)
        self.v_proj = nn.Conv2d(channels, channels, kernel_size=1)
        self.out_proj = nn.Conv2d(channels, channels, kernel_size=1)

    def forward(self, f_fusion: torch.Tensor) -> torch.Tensor:
        B, C, H, W = f_fusion.shape
        N = H * W

        q = self.q_proj(f_fusion).view(B, self.num_heads, self.head_dim, N)
        k = self.k_proj(f_fusion).view(B, self.num_heads, self.head_dim, N)
        v = self.v_proj(f_fusion).view(B, self.num_heads, self.head_dim, N)

        attn = torch.einsum("bhdn,bhdm->bhnm", q, k) / (self.head_dim ** 0.5)  # QK^T/sqrt(d)
        attn = attn.softmax(dim=-1)                                            # Softmax(.)
        out = torch.einsum("bhnm,bhdm->bhdn", attn, v)                         # (.) V
        out = out.reshape(B, C, H, W)
        out = self.out_proj(out)

        f_r = f_fusion + out    # F_r = F_fusion + A(F_fusion)
        return f_r


# ---------------------------------------------------------------------------
# Anomaly detection head: C = sigma(W_c F_r + b_c) ; B = W_b F_r + b_b
# ---------------------------------------------------------------------------
class DetectionHead(nn.Module):
    def __init__(self, in_channels: int, num_classes: int):
        super().__init__()
        self.cls_head = nn.Conv2d(in_channels, num_classes, kernel_size=1)  # W_c, b_c
        self.reg_head = nn.Conv2d(in_channels, 4, kernel_size=1)             # W_b, b_b
        self.conf_head = nn.Conv2d(in_channels, 1, kernel_size=1)            # confidence S

    def forward(self, f_r: torch.Tensor):
        cls_logits = self.cls_head(f_r)          # [B, num_classes, H, W] (pre-sigmoid)
        reg = self.reg_head(f_r)                  # [B, 4, H, W]  (cx, cy, w, h) offsets
        conf_logits = self.conf_head(f_r)         # [B, 1, H, W]  (pre-sigmoid)
        return cls_logits, reg, conf_logits


# ---------------------------------------------------------------------------
# Full hybrid framework
# ---------------------------------------------------------------------------
class HybridYOLOYOWOv3(nn.Module):
    def __init__(self, num_classes: int, spatial_backbone: str = "yolov8n",
                 temporal_backbone: str = "r3d_18", inter_channels: int = 256,
                 fusion_channels: int = 256, attn_heads: int = 4, pretrained: bool = True, variant: str = "complete"):
        super().__init__()
        if variant not in {"complete", "fusion_no_attention", "spatial_only", "temporal_only"}:
            raise ValueError(f"Unknown variant: {variant}")
        self.variant = variant
        self.spatial_branch = SpatialBranch(spatial_backbone, pretrained, inter_channels) if variant != "temporal_only" else None
        self.temporal_branch = TemporalBranch(temporal_backbone, pretrained, inter_channels) if variant != "spatial_only" else None
        self.fusion = FusionModule(inter_channels, inter_channels, fusion_channels) if variant in {"complete", "fusion_no_attention"} else None
        self.single_projection = nn.Conv2d(inter_channels, fusion_channels, 1) if self.fusion is None else None
        self.attn_refine = SelfAttentionRefine(fusion_channels, attn_heads) if variant == "complete" else nn.Identity()
        self.detect_head = DetectionHead(fusion_channels, num_classes)

    def forward(self, clip: torch.Tensor, key_frame: torch.Tensor):
        if self.variant == "spatial_only":
            f_fusion = self.single_projection(self.spatial_branch(key_frame))
        elif self.variant == "temporal_only":
            f_fusion = self.single_projection(self.temporal_branch(clip))
        else:
            f_s = self.spatial_branch(key_frame)
            f_t = self.temporal_branch(clip)
            f_fusion = self.fusion(f_s, f_t)
        f_r = self.attn_refine(f_fusion)            # F_r
        cls_logits, reg, conf_logits = self.detect_head(f_r)
        return {
            "cls_logits": cls_logits,    # -> C
            "reg": reg,                  # -> B
            "conf_logits": conf_logits,  # -> S
        }


def build_model(cfg, pretrained=None):
    m = cfg["model"]
    return HybridYOLOYOWOv3(num_classes=cfg["data"]["num_classes"],
        spatial_backbone=m["spatial_backbone"], temporal_backbone=m["temporal_backbone"],
        inter_channels=m["inter_channels"], fusion_channels=m["fusion_channels"],
        attn_heads=m["attn_heads"], pretrained=m["pretrained"] if pretrained is None else pretrained,
        variant=m.get("variant", "complete"))
