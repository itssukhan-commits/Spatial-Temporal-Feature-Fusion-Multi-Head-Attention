# UCF-Crime2Local dataset preparation

This package expects consecutive source frames and actual spatial annotations,
not image-level anomaly labels. User-supplied raw dataset bytes are separate from
this source release. Keep original dataset attribution, license/terms and source
checksums with the dataset archive.

## CSV contract

`video_id,frame_idx,cls,x,y,w,h,t`

- `video_id`: path relative to `frames/`, e.g. `Arrest/Arrest028`; the same spelling
  is used throughout annotations, decoded frames and predictions.
- `frame_idx`: integer, zero based. Frame zero is the first decoded source frame.
- `cls`: 0 Arrest; 1 Assault; 2 Burglary; 3 Robbery; 4 Stealing; 5 Vandalism.
- `x,y,w,h`: normalized center coordinates and dimensions relative to the original
  frame. Positive widths/heights, finite values, whole GT box within image bounds.
- `t`: binary temporal metadata, retained but not used as a localization target.
- One row per actual annotated box. An explicitly verified negative frame has
  one row with `cls=-1`, `x=y=w=h=t=0`. Missing annotations are not negatives.

The three eligible manifests must be video-disjoint. Dataset audits detect
identifier overlap, malformed boxes, duplicate rows and missing causal context
frames. They do not establish absence of renamed duplicate video content.

## Explicit adaptation

If your native data is tabular, `import_annotations.py` converts a CSV with
explicit options. It does not guess the raw UCF-Crime2Local annotation format.

```bash
python import_annotations.py --input original_train.csv --output ucfcrime2local/annotations/train.csv --frames-root ucfcrime2local/frames --coordinates normalized-xywh --frame-base 0
```

For pixel corner boxes use `--coordinates pixel-xyxy` with columns
`xmin,ymin,xmax,ymax,image_width,image_height`. If input columns differ, pass a
JSON mapping canonical names to existing names with `--mapping`. Use
`--frame-base 1` only when source indices are explicitly one based. Do not invent
class IDs, boxes, t values, negative rows, or historical split membership.

If your archive contains original videos, provide a JSON mapping each video_id
to its original video file and decode the required context windows:

```bash
python extract_frames.py --video-map video_map.json --annotations ucfcrime2local/annotations/train.csv ucfcrime2local/annotations/val.csv ucfcrime2local/annotations/test.csv --frames-root ucfcrime2local/frames --clip-length 32
```

Extraction uses sequential zero-based OpenCV decoding and JPEG quality 95. Match
these settings to the actual historical extraction before claiming exact
reproduction. Existing frames are protected unless `--overwrite` is supplied.
32-frame extraction supports all context-sensitivity runs. Variable-frame-rate
video correspondence must be resolved against the original annotation convention.

## Counts and target collisions

Author-reported eligible partitions: 52/13/31 source videos, 20,000/5,000/8,000
key frames, 25,000/6,250/10,000 box instances. Listed annotation-path counts
31,687/13,226 refer to a different accounting unit and must not be reconstructed
by arbitrary sampling. Preserve original inclusion/exclusion manifests.

Use the recorded output grid from `tensor_shapes.json` with
`audit_dataset.py --grid HEIGHT WIDTH` to count additional instances assigned to
occupied regression cells. Do not assume a 7×7 grid without the trace. These
training-assignment collisions do not remove GT boxes from evaluation.
