# GitHub and Zenodo deposit

1. Extract the source archive and run the tests in the documented environment.
2. Add the actual dataset, original source/terms, frame-index and coordinate
   descriptions, exact partition manifests and extraction provenance.
3. Run the notebook/workflow or deposit your historical run records. Keep
   imported historical records identifiable and preserve their original hashes.
4. Confirm that actual predictions reproduce the manuscript ledger and class AP;
   use `check_reported_values.py` without overwriting generated results.
5. Retain all component, seed, clip-length, NMS, error-analysis and bootstrap
   records. Three training seeds and test-video resampling answer different questions.
6. Verify the hardware/precision/timing scopes. The JPEG-frame profiler does not
   prove a compressed-video-container decoding measurement.
7. Add your actual code license, repository URL, version and DOI. Retain dependency
   license notices. Dataset licensing is separate.
8. Upload source/notebook/docs/tests to GitHub. Use Zenodo for large actual
   checkpoints, prediction archives and the separately licensed dataset. Update
   `CITATION.cff`, README and manuscript availability text with the resulting DOI.
9. Preserve `source_sha256.json` and `run_sha256.json`. Check archive integrity
   before publication. No external account publishing is performed by this package.

The source can be uploaded as a software deposit. A manuscript evidence deposit
is complete only when its real experiment/data records are attached; source code
alone does not supply those historical measurements.
