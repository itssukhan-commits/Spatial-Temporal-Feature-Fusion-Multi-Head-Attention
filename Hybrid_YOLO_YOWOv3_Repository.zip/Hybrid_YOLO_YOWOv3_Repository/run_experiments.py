"""Execute manuscript experiment matrix with isolated run directories and raw logs."""
import argparse
import subprocess
import sys
from pathlib import Path
import yaml
from configure import configure
from runtime import write_json


def logged(command, path):
    with Path(path).open('w',encoding='utf-8') as log:
        proc=subprocess.Popen([sys.executable,'-u',*command],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        for line in proc.stdout:print(line,end='');log.write(line);log.flush()
        code=proc.wait()
    if code:raise RuntimeError(f'Command failed; inspect {path}')


def main():
    p=argparse.ArgumentParser();p.add_argument('--data-root',required=True);p.add_argument('--output',default='runs')
    p.add_argument('--all',action='store_true',help='Three seeds, component ablations, 8/32-frame retraining, reference analyses')
    p.add_argument('--device',default='cuda');p.add_argument('--bootstrap',type=int,default=1000)
    p.add_argument('--skip-training',action='store_true',help='Analyze already populated run directories')
    a=p.parse_args();jobs=[('complete',16,42)]
    if a.all:jobs += [('complete',16,21),('complete',16,84),('spatial_only',16,42),('temporal_only',16,42),
                     ('fusion_no_attention',16,42),('complete',8,42),('complete',32,42)]
    summaries=[]
    for variant,length,seed in jobs:
        run=Path(a.output)/f'{variant}_T{length}_seed{seed}';run.mkdir(parents=True,exist_ok=True)
        config=run/'config.yaml';cfg=configure('configs/config.yaml',a.data_root,seed,variant,length,a.device)
        if a.skip_training:
            if not config.exists() or not (run/'best.pt').exists():raise FileNotFoundError(f'Missing existing config/checkpoint in {run}')
        else:
            if (run/'history.csv').exists():raise FileExistsError(f'Run exists: {run}; use --skip-training or a different output root')
            config.write_text(yaml.safe_dump(cfg,sort_keys=False))
            logged(['train.py','--config',str(config),'--out_dir',str(run)],run/'train.log')
        logged(['evaluate.py','--config',str(config),'--checkpoint',str(run/'best.pt'),'--output',str(run/'evaluation')],run/'evaluate.log')
        import json
        summaries.append(json.loads((run/'evaluation/results.json').read_text()))
    write_json(Path(a.output)/'experiment_results.json',summaries)
    ref=Path(a.output)/'complete_T16_seed42'
    logged(['analysis.py','--predictions',str(ref/'evaluation/predictions.json'),'--output',str(ref/'analysis'),
            '--bootstrap',str(a.bootstrap)],ref/'analysis.log')
    logged(['profile.py','--config',str(ref/'config.yaml'),'--checkpoint',str(ref/'best.pt'),
            '--output',str(ref/'profiling')],ref/'profile.log')
    logged(['plot_results.py','--runs',a.output,'--output',str(Path(a.output)/'figures')],Path(a.output)/'figures.log')


if __name__=='__main__':main()
