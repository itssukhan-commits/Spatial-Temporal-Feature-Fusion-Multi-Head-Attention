# Refinement summary

- Align standalone and notebook defaults: six classes, 16 frames, 224×224, 30 epochs, seed 42, workers two, no primary NMS, AP floor 0.001.
- Replace automatic CPU fallback with explicit device selection.
- Preserve routed YOLO connections and initialize lazy projection before optimizer construction.
- Add optional controlled components and 8/32-frame retraining with isolated run histories.
- Export one-based epochs, per-epoch learning rate, actual counts/AP and checkpoint-linked predictions.
- Correct assignment comments: one regression target per box-center cell, not FCOS center sampling.
- Add validated CSV adaptation, original-video frame extraction, split audit, collision counts and intermediate shape traces.
- Add threshold/NMS/error/cluster-bootstrap analyses, original-pixel overlays and record-derived chart generation.
- Record profiling scopes, partial THOP coverage and actual stage timings; distinguish JPEG frames from video containers.
- Add author-reported reference manifest, tests, GitHub CI, citation, attribution and release/export documentation.
- Notebook has no manufactured research outputs or placeholder checkpoints.

Seven protocol tests passed; the optional dependency-backed model test was skipped in the preparation environment. See VALIDATION.json for scope.
