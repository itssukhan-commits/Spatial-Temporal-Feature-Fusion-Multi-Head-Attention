"""Compare generated records with author-reported manuscript values; never overwrite results."""
import argparse
import json
from pathlib import Path
from runtime import write_json


def main():
    p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--reference',default='reported/reference_values.json')
    p.add_argument('--output',default='artifacts/reference_comparison.json');p.add_argument('--tolerance',type=float,default=.0051)
    a=p.parse_args();actual=json.loads(Path(a.results).read_text());reference=json.loads(Path(a.reference).read_text())
    checks={}
    for key,target in reference['reference_run'].items():
        if key not in actual:continue
        value=actual[key];checks[key]={'reported':target,'generated':value,'difference':value-target,
                                      'matches_rounding':abs(value-target)<=a.tolerance}
    write_json(a.output,{'reference_provenance':reference['provenance'],'checks':checks,
                         'all_compared_values_match':all(v['matches_rounding'] for v in checks.values())})
    print(a.output)


if __name__=='__main__':main()
