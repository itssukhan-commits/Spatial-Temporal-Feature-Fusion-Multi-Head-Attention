"""Train the hybrid model with AdamW and select checkpoints by validation loss."""
import argparse
import csv
import json
import os
import time

import torch
import yaml
from torch.optim import AdamW
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import AnomalyClipDataset, collate_fn
from model import build_model
from losses import hybrid_loss
from utils import set_seed, save_checkpoint, count_parameters


def build_dataloader(cfg, split="train"):
    csv_key = {"train": "train_csv", "val": "val_csv", "test": "test_csv"}[split]
    ds = AnomalyClipDataset(
        csv_path=cfg["data"][csv_key],
        frames_root=cfg["data"]["frames_root"],
        clip_len=cfg["data"]["clip_len"],
        img_size=cfg["data"]["img_size"],
        num_classes=cfg["data"]["num_classes"],
        is_train=(split == "train"),
    )
    return DataLoader(
        ds,
        batch_size=cfg["train"]["batch_size"],
        shuffle=(split == "train"),
        num_workers=cfg["train"]["num_workers"],
        collate_fn=collate_fn,
        drop_last=False,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/config.yaml")
    parser.add_argument("--out_dir", type=str, default="runs/exp1")
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    set_seed(cfg["train"]["seed"])
    from runtime import resolve_device, environment, write_json
    from audit_dataset import audit
    device = resolve_device(cfg)
    dataset_audit = audit(cfg, check_frames=True)
    if os.path.exists(os.path.join(args.out_dir, "history.csv")):
        raise FileExistsError("Existing run history: choose a new output directory to avoid overwriting records.")
    print(f"[train] using device: {device}")

    # ---- Step 1: annotated dataset ----
    train_loader = build_dataloader(cfg, "train")
    val_loader = build_dataloader(cfg, "val")

    # ---- Model ----
    model = build_model(cfg).to(device)

    from runtime import initialize
    os.makedirs(args.out_dir, exist_ok=True)
    shapes = initialize(model, cfg, device, os.path.join(args.out_dir, "tensor_shapes.json"))
    collision_audit = audit(cfg, check_frames=False, grid=shapes["outputs"]["cls_logits"][-2:])
    for split in ["train", "val", "test"]:
        for key in ["collision_assignments", "collision_grid", "collision_percent"]:
            dataset_audit[split][key] = collision_audit[split][key]
    print(f"[train] model parameters: {count_parameters(model):.2f} M")

    optimizer = AdamW(model.parameters(), lr=cfg["train"]["learning_rate"],
                       weight_decay=cfg["train"]["weight_decay"])
    scheduler = torch.optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=cfg["train"]["lr_decay_epochs"], gamma=cfg["train"]["lr_decay_factor"]
    )
    scaler = torch.cuda.amp.GradScaler(enabled=cfg["train"]["amp"] and device.type == "cuda")

    os.makedirs(args.out_dir, exist_ok=True)
    best_val_loss = float("inf")
    with open(os.path.join(args.out_dir,"config.json"),"w") as f: json.dump(cfg,f,indent=2)
    write_json(os.path.join(args.out_dir, "environment.json"), environment(device))
    write_json(os.path.join(args.out_dir, "dataset_audit.json"), dataset_audit)
    history = []

    for epoch in range(cfg["train"]["epochs"]):
        epoch_lr = optimizer.param_groups[0]["lr"]
        model.train()
        running_loss = 0.0
        optimizer.zero_grad()

        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{cfg['train']['epochs']}")
        for step, batch in enumerate(pbar):
            clips = batch["clips"].to(device)
            key_frames = batch["key_frames"].to(device)
            boxes = batch["boxes"]  # list, kept on CPU->moved inside loss fn

            # ---- Steps 3-6: forward through spatial+temporal+fusion+head ----
            with torch.cuda.amp.autocast(enabled=cfg["train"]["amp"] and device.type == "cuda"):
                preds = model(clips, key_frames)
                # ---- Step 7: compute losses ----
                loss_dict = hybrid_loss(
                    preds, boxes, cfg["data"]["num_classes"],
                    lambda_box=cfg["train"]["lambda_box"],
                    lambda_conf=cfg["train"]["lambda_conf"],
                )
                group_start = (step // cfg["train"]["grad_accum_steps"]) * cfg["train"]["grad_accum_steps"]
                group_size = min(cfg["train"]["grad_accum_steps"], len(train_loader) - group_start)
                loss = loss_dict["loss"] / group_size

            # ---- Step 8: backprop / update ----
            scaler.scale(loss).backward()
            if (step + 1) % cfg["train"]["grad_accum_steps"] == 0 or step + 1 == len(train_loader):
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            running_loss += loss_dict["loss"].item()
            pbar.set_postfix({
                "loss": f"{loss_dict['loss'].item():.4f}",
                "cls": f"{loss_dict['loss_cls'].item():.4f}",
                "box": f"{loss_dict['loss_box'].item():.4f}",
                "conf": f"{loss_dict['loss_conf'].item():.4f}",
            })

        scheduler.step()
        avg_train_loss = running_loss / max(len(train_loader), 1)

        # ---- validation ----
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in val_loader:
                clips = batch["clips"].to(device)
                key_frames = batch["key_frames"].to(device)
                boxes = batch["boxes"]
                preds = model(clips, key_frames)
                loss_dict = hybrid_loss(preds, boxes, cfg["data"]["num_classes"],
                                         lambda_box=cfg["train"]["lambda_box"],
                                         lambda_conf=cfg["train"]["lambda_conf"])
                val_loss += loss_dict["loss"].item()
        avg_val_loss = val_loss / max(len(val_loader), 1)

        print(f"[epoch {epoch+1}] train_loss={avg_train_loss:.4f} val_loss={avg_val_loss:.4f}")

        history.append({"epoch":epoch+1,"train_loss":avg_train_loss,"val_loss":avg_val_loss,"learning_rate":epoch_lr})
        with open(os.path.join(args.out_dir,"history.csv"),"w",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=list(history[0]));writer.writeheader();writer.writerows(history)
        ckpt = {
            "epoch": epoch + 1,
            "epoch_index_zero_based": epoch,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "scheduler_state": scheduler.state_dict(),
            "scaler_state": scaler.state_dict(),
            "best_val_loss": min(best_val_loss, avg_val_loss),
            "config": cfg,
        }
        save_checkpoint(ckpt, os.path.join(args.out_dir, "last.pt"))
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(ckpt, os.path.join(args.out_dir, "best.pt"))
            print(f"[epoch {epoch+1}] new best checkpoint saved (val_loss={best_val_loss:.4f})")

    print("[train] Completed fixed 30-epoch schedule; best.pt selected by minimum validation loss.")


if __name__ == "__main__":
    main()
