"""Loads consecutive RGB clips ending at a labeled key frame.
Requires verified normalized center-format bounding boxes and explicit negative frames.
Class labels on isolated images are insufficient for temporal localization training."""
import os
from typing import List, Dict

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


class AnomalyClipDataset(Dataset):
    def __init__(self, csv_path: str, frames_root: str, clip_len: int = 16,
                 img_size: int = 224, num_classes: int = 6, is_train: bool = True):
        self.frames_root = frames_root
        self.clip_len = clip_len
        self.img_size = img_size
        self.num_classes = num_classes
        self.is_train = is_train

        from audit_dataset import validate_annotations
        from pathlib import Path
        self.frames_root = str(Path(frames_root).resolve())
        df = pd.read_csv(csv_path)
        validate_annotations(df, self.frames_root, num_classes)
        required = {"video_id", "frame_idx", "cls", "x", "y", "w", "h", "t"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(f"Annotation CSV is missing columns: {missing}")

        # Group boxes by (video_id, frame_idx) -> list of box dicts
        self.samples: List[Dict] = []
        grouped = df.groupby(["video_id", "frame_idx"])
        for (video_id, frame_idx), group in grouped:
            boxes = group.loc[group["cls"] >= 0, ["cls", "x", "y", "w", "h"]].values.astype(np.float32)
            self.samples.append({
                "video_id": str(video_id),
                "frame_idx": int(frame_idx),
                "boxes": boxes,  # [num_boxes, 5] -> (cls, x, y, w, h)
            })

    def __len__(self):
        return len(self.samples)

    def _load_frame(self, video_id: str, frame_idx: int) -> np.ndarray:
        path = os.path.join(self.frames_root, video_id, f"{frame_idx}.jpg")
        if not os.path.isfile(path):
            path = os.path.join(self.frames_root, video_id, f"{frame_idx:05d}.jpg")
        img = cv2.imread(path)
        if img is None:
            raise FileNotFoundError(f"Missing frame: {path}")
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (self.img_size, self.img_size))
        return img

    def _load_clip(self, video_id: str, key_frame_idx: int) -> torch.Tensor:
        """
        Builds X_t = {I_max(0,t-k+1), ..., I_t} ending at the annotated key frame,
        clamping at the start of the video if fewer than k prior frames exist.
        """
        frames = []
        start = max(0, key_frame_idx - self.clip_len + 1)
        indices = list(range(start, key_frame_idx + 1))
        # left-pad by repeating the first available frame if the clip is short
        while len(indices) < self.clip_len:
            indices.insert(0, indices[0])

        for idx in indices:
            frames.append(self._load_frame(video_id, idx))

        clip = np.stack(frames, axis=0)              # [T, H, W, 3]
        clip = clip.astype(np.float32) / 255.0
        clip = (clip - 0.45) / 0.225                  # simple normalization
        clip = torch.from_numpy(clip).permute(3, 0, 1, 2)  # [3, T, H, W]
        return clip

    def __getitem__(self, idx: int):
        sample = self.samples[idx]
        video_id = sample["video_id"]
        frame_idx = sample["frame_idx"]

        clip = self._load_clip(video_id, frame_idx)         # [3, T, H, W] for temporal branch
        key_frame = clip[:, -1, :, :]                        # [3, H, W] for spatial branch

        boxes = torch.from_numpy(sample["boxes"])            # [num_boxes, 5]

        return {
            "clip": clip,
            "key_frame": key_frame,
            "boxes": boxes,               # (cls, x, y, w, h), normalized
            "video_id": video_id,
            "frame_idx": frame_idx,
        }


def collate_fn(batch):
    """Handles variable number of boxes per sample."""
    clips = torch.stack([b["clip"] for b in batch], dim=0)
    key_frames = torch.stack([b["key_frame"] for b in batch], dim=0)
    boxes = [b["boxes"] for b in batch]  # list of [num_boxes_i, 5] tensors
    video_ids = [b["video_id"] for b in batch]
    frame_idxs = [b["frame_idx"] for b in batch]
    return {
        "clips": clips,
        "key_frames": key_frames,
        "boxes": boxes,
        "video_ids": video_ids,
        "frame_idxs": frame_idxs,
    }
