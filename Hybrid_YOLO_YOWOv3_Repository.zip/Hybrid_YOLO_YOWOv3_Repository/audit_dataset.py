"""Fail-fast annotation, video-split, temporal-frame and target collision audit."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
from runtime import write_json, sha256

COLUMNS = ['video_id', 'frame_idx', 'cls', 'x', 'y', 'w', 'h', 't']


def frame_path(root, video_id, frame_idx):
    for name in [f'{frame_idx}.jpg', f'{frame_idx:05d}.jpg']:
        path = Path(root) / video_id / name
        if path.is_file(): return path
    raise FileNotFoundError(f'Missing temporal frame: {root}/{video_id}/{frame_idx}.jpg')


def validate_annotations(df, frames_root, num_classes=6):
    if df.empty or not set(COLUMNS) <= set(df.columns):
        raise ValueError('Nonempty CSV required with columns: ' + ','.join(COLUMNS))
    if df[COLUMNS].isna().any().any(): raise ValueError('Missing annotation values')
    root = Path(frames_root).resolve()
    for value in df.video_id.unique():
        if not isinstance(value, str) or not value or not (root / value).resolve().is_relative_to(root):
            raise ValueError(f'Invalid or escaping video_id: {value!r}')
    for col in ['frame_idx', 'cls', 't']:
        a = pd.to_numeric(df[col], errors='raise').to_numpy()
        if not np.isfinite(a).all() or not (a == np.floor(a)).all(): raise ValueError(f'{col} must be finite integers')
    if (df.frame_idx < 0).any(): raise ValueError('Frame indices must be zero based and nonnegative')
    if not df.cls.isin(range(-1, num_classes)).all() or not df.t.isin([0, 1]).all():
        raise ValueError('Invalid class or temporal metadata')
    a = df[['x','y','w','h']].to_numpy(dtype=float)
    if not np.isfinite(a).all(): raise ValueError('Nonfinite bounding boxes')
    p = df.cls >= 0; x,y,w,h = a[p].T
    if ((w <= 0) | (h <= 0) | (x-w/2 < -1e-7) | (y-h/2 < -1e-7) |
        (x+w/2 > 1+1e-7) | (y+h/2 > 1+1e-7)).any(): raise ValueError('Invalid normalized center-format box')
    for _, rows in df.groupby(['video_id', 'frame_idx'], sort=False):
        neg = rows.cls == -1
        if neg.any() and (len(rows) != 1 or (rows[['x','y','w','h','t']].to_numpy() != 0).any()):
            raise ValueError('Negative frame requires exactly one cls=-1 sentinel with zero coordinates and t=0')
    if df.duplicated(COLUMNS).any(): raise ValueError('Duplicate annotation rows: resolve rather than silently drop')


def audit(cfg, check_frames=True, grid=None):
    result, ids = {}, {}
    for split in ['train', 'val', 'test']:
        path = cfg['data'][split+'_csv']; df = pd.read_csv(path)
        validate_annotations(df, cfg['data']['frames_root'], cfg['data']['num_classes'])
        ids[split] = set(df.video_id.unique()); groups = df.groupby(['video_id','frame_idx'], sort=False)
        positive = sum((rows.cls >= 0).any() for _,rows in groups)
        item = {'annotation_rows':len(df), 'videos':len(ids[split]), 'key_frames':len(groups),
                'positive_key_frames':int(positive), 'negative_key_frames':len(groups)-int(positive),
                'gt_instances':int((df.cls >= 0).sum()), 'csv_sha256':sha256(path),
                'class_support':{name:{'videos':int(df[df.cls==c].video_id.nunique()),
                    'gt_instances':int((df.cls==c).sum())} for c,name in enumerate(cfg['data']['class_names'])}}
        if check_frames:
            checked = set()
            for (video, frame), rows in groups:
                for index in range(max(0,int(frame)-cfg['data']['clip_len']+1),int(frame)+1):
                    key=(video,index)
                    if key not in checked:
                        frame_path(cfg['data']['frames_root'],video,index); checked.add(key)
            item['required_frames_checked'] = len(checked)
        if grid:
            height,width = grid; collisions=0
            for _,rows in groups:
                occupied=set()
                for row in rows[rows.cls>=0].itertuples():
                    cell=(min(height-1,int(row.y*height)),min(width-1,int(row.x*width)))
                    collisions += cell in occupied; occupied.add(cell)
            item.update(collision_assignments=int(collisions), collision_grid=list(grid),
                        collision_percent=100*collisions/max(item['gt_instances'],1))
        result[split] = item
    for a,b in [('train','val'),('train','test'),('val','test')]:
        overlap=ids[a]&ids[b]
        if overlap: raise ValueError(f'Video identifier leakage {a}/{b}: {sorted(overlap)}')
    result['checks']={'video_identifier_disjoint':True, 'all_retained_boxes_valid':True,
                      'frames_checked':check_frames, 'renamed_content_duplicates_checked':False}
    return result


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',default='configs/config.yaml')
    p.add_argument('--output',default='artifacts/dataset_audit.json');p.add_argument('--grid',nargs=2,type=int)
    p.add_argument('--skip-frame-check',action='store_true');a=p.parse_args()
    cfg=yaml.safe_load(Path(a.config).read_text())
    write_json(a.output,audit(cfg,not a.skip_frame_check,a.grid))
    print('Dataset audit passed:',a.output)
