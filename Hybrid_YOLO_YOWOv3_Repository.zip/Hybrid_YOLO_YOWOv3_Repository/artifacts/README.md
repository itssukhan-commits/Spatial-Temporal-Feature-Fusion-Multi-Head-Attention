# Experimental evidence

No historical experiment files were present in the supplied notebook. This
release generates them from actual execution or supports depositing your existing
records. Do not substitute reference values or software-test fixtures for them.

For each run retain `config.yaml`, `config.json`, `environment.json`,
`dataset_audit.json`, `tensor_shapes.json`, 30-row `history.csv` (with learning
rate), `best.pt`, `last.pt`, `train.log`, and `evaluate.log`.

Evaluation retains checkpoint-linked `predictions.json` including video/frame
IDs, GT boxes and scored predictions; unrounded/rounded summaries; class counts/AP;
matching records; hashes; environment and shape trace.

Reference analyses retain threshold sweep, mutually exclusive FP categories,
NMS sensitivity, 1,000 video bootstrap replicate metrics and intervals, and logs.
Independent seeds and component/context variants retain separate complete records.

Profiling retains individual forward durations, actual stage durations, precision,
input shape, synchronization, hardware/software and peak allocated-memory scope.
Figure 8 exports original frame overlays plus matching/source-hash records.
All other experimental charts read real run files, never `reported/` reference
values. Missing analyses are recorded in a figure manifest rather than fabricated.

Checkpoint epoch fields in this release are one based. Older checkpoint fields
may be zero based; do not change their interpretation silently. Preserve
historical originals when importing records, and document compatibility changes.
