"""Resolve dataset paths without modifying the versioned base configuration."""
import argparse
from pathlib import Path
import yaml


def configure(base, data_root, seed=42, variant='complete', clip_len=16, device='cuda'):
    cfg=yaml.safe_load(Path(base).read_text());root=Path(data_root).expanduser().resolve()
    for split in ['train','val','test']:cfg['data'][split+'_csv']=str(root/'annotations'/f'{split}.csv')
    cfg['data']['frames_root']=str(root/'frames');cfg['data']['clip_len']=clip_len
    cfg['train']['seed']=seed;cfg['model']['variant']=variant;cfg['hardware']['device']=device
    return cfg


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-root',required=True);p.add_argument('--base',default='configs/config.yaml')
    p.add_argument('--output',default='configs/local.yaml');p.add_argument('--device',default='cuda')
    a=p.parse_args();out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(yaml.safe_dump(configure(a.base,a.data_root,device=a.device),sort_keys=False))
    print(out)
