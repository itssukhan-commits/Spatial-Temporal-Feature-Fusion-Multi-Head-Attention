"""Record-derived localization analysis. Pure NumPy; no model or dataset image dependency."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from runtime import write_json, sha256

NAMES=['Arrest','Assault','Burglary','Robbery','Stealing','Vandalism']


def iou(box, boxes):
    boxes=np.asarray(boxes,dtype=float).reshape(-1,4)
    if not len(boxes): return np.empty(0)
    box=np.asarray(box,dtype=float)
    left=box[:2]-box[2:]/2;right=box[:2]+box[2:]/2
    lo=boxes[:,:2]-boxes[:,2:]/2;hi=boxes[:,:2]+boxes[:,2:]/2
    overlap=np.maximum(0,np.minimum(right,hi)-np.maximum(left,lo)).prod(1)
    return overlap/np.maximum(box[2:].prod()+boxes[:,2:].prod(1)-overlap,1e-7)


def match(detections, ground_truth, threshold=.5):
    """Highest-IoU same-class target; no reassignment when that target is occupied."""
    gt=np.asarray(ground_truth,dtype=float).reshape(-1,5); used=set(); rows=[]
    for index,det in sorted(enumerate(detections),key=lambda v:-v[1]['score']):
        overlaps=iou(det['box'],gt[:,1:]); same=np.where(gt[:,0]==det['cls'])[0]
        best=int(same[np.argmax(overlaps[same])]) if len(same) else None
        value=float(overlaps[best]) if best is not None else 0.
        tp=best is not None and value>=threshold and best not in used
        if tp: used.add(best);category='true_positive'
        elif best is not None and value>=threshold and best in used: category='duplicate_or_assignment_conflict'
        elif any(overlaps[k]>=threshold for k in range(len(gt)) if gt[k,0]!=det['cls']): category='wrong_class'
        elif len(overlaps) and overlaps.max()>=.1: category='insufficient_overlap'
        else: category='background_or_negligible_overlap'
        rows.append({'detection_index':index,'cls':int(det['cls']),'score':float(det['score']),
                     'tp':int(tp),'fp':int(not tp),'target_index':best,'same_class_iou':value,
                     'max_any_iou':float(overlaps.max()) if len(overlaps) else 0.,'category':category})
    return rows,sorted(set(range(len(gt)))-used)


def interpolated_ap(scored, gt_count):
    if gt_count==0 or not len(scored):return 0.
    arr=np.asarray(scored,dtype=float).reshape(-1,3)
    arr=arr[np.argsort(-arr[:,0],kind='stable')]
    tp=np.cumsum(arr[:,1]); fp=np.cumsum(arr[:,2]);rec=tp/gt_count;prec=tp/np.maximum(tp+fp,1e-9)
    rec=np.r_[0.,rec,1.];prec=np.r_[1.,prec,0.]
    prec=np.maximum.accumulate(prec[::-1])[::-1];j=np.flatnonzero(rec[1:]!=rec[:-1])
    return float(np.sum((rec[j+1]-rec[j])*prec[j+1]))


def nms(detections, threshold=.5):
    keep=[]
    for det in sorted(detections,key=lambda d:-d['score']):
        boxes=[d['box'] for d in keep if d['cls']==det['cls']]
        if not boxes or iou(det['box'],boxes).max()<=threshold:keep.append(det)
    return keep


def counts_to_metrics(tp,fp,gt):
    fn=gt-tp
    return {'GT':int(gt),'TP':int(tp),'FP':int(fp),'FN':int(fn),
            'precision':100*tp/max(tp+fp,1),'recall':100*tp/max(gt,1),
            'f1':200*tp/max(2*tp+fp+fn,1)}


def summarize(records, confidence=.3, overlap=.5, floor=.001, use_nms=False, nms_iou=.5, names=NAMES):
    gt_count=np.zeros(len(names),dtype=int);tp=np.zeros_like(gt_count);fp=np.zeros_like(gt_count)
    scored=[[] for _ in names];errors=defaultdict(int);outcomes=[]
    for record in records:
        gt=np.asarray(record['ground_truth'],dtype=float).reshape(-1,5)
        ds=[d for d in record['detections'] if d['score']>=floor]
        if use_nms:ds=nms(ds,nms_iou)
        for c in range(len(names)):gt_count[c]+=int((gt[:,0]==c).sum())
        all_matches,_=match(ds,gt,overlap)
        for row in all_matches:scored[row['cls']].append([row['score'],row['tp'],row['fp']])
        op=[d for d in ds if d['score']>=confidence];rows,missing=match(op,gt,overlap)
        for row in rows:
            tp[row['cls']]+=row['tp'];fp[row['cls']]+=row['fp']
            if row['fp']:errors[row['category']]+=1
        outcomes.append({'video_id':record['video_id'],'frame_idx':record['frame_idx'],
                         'detections':op,'ground_truth':gt.tolist(),'matching':rows,'unmatched_gt_indices':missing})
    classes=[]
    for c,name in enumerate(names):
        classes.append({'class':name,**counts_to_metrics(tp[c],fp[c],gt_count[c]),'AP50':100*interpolated_ap(scored[c],gt_count[c])})
    pooled=counts_to_metrics(int(tp.sum()),int(fp.sum()),int(gt_count.sum()))
    pooled['mAP50']=float(np.mean([x['AP50'] for x in classes]))
    pooled.update(confidence=confidence,matching_iou=overlap,ap_score_floor=floor,nms=use_nms,
                  per_class=classes,fp_categories=dict(errors))
    return pooled,outcomes


def bootstrap(records, replicates=1000, seed=2026, confidence=.3, overlap=.5, floor=.001):
    """Cache per-video matches; resample videos with multiplicity, retaining every frame/GT."""
    groups=defaultdict(list)
    for r in records:groups[r['video_id']].append(r)
    cached=[]
    for video in sorted(groups):
        rs=groups[video];totals,_=summarize(rs,confidence,overlap,floor);scores=[[] for _ in NAMES]
        for r in rs:
            rows,_=match([d for d in r['detections'] if d['score']>=floor],r['ground_truth'],overlap)
            for row in rows:scores[row['cls']].append([row['score'],row['tp'],row['fp']])
        cached.append((totals,[np.asarray(v,dtype=float).reshape(-1,3) for v in scores]))
    if not cached:raise ValueError('No test videos')
    rng=np.random.default_rng(seed);samples=[]
    for _ in range(replicates):
        # Every selection is a distinct replica of the video, including its matched targets.
        selected=rng.integers(0,len(cached),len(cached));tp=fp=gt=0;aps=[]
        for j in selected:
            t=cached[j][0];tp+=t['TP'];fp+=t['FP'];gt+=t['GT']
        metrics=counts_to_metrics(tp,fp,gt)
        for c in range(len(NAMES)):
            chunks=[cached[j][1][c] for j in selected]
            class_gt=sum(cached[j][0]['per_class'][c]['GT'] for j in selected)
            aps.append(100*interpolated_ap(np.concatenate(chunks),class_gt))
        samples.append([metrics['precision'],metrics['recall'],float(np.mean(aps))])
    arr=np.asarray(samples)
    return {'method':'video-cluster percentile bootstrap','replicates':replicates,'bootstrap_seed':seed,
            'videos':len(cached),'checkpoint_fixed':True,'interval_level':.95,
            'percentile_intervals':{name:np.percentile(arr[:,i],[2.5,97.5]).tolist()
                                   for i,name in enumerate(['precision','recall','mAP50'])},
            'replicate_values':arr.tolist(),'absent_class_ap':0,'class_denominator':6}


def main():
    p=argparse.ArgumentParser();p.add_argument('--predictions',required=True);p.add_argument('--output',required=True)
    p.add_argument('--bootstrap',type=int,default=1000);p.add_argument('--bootstrap-seed',type=int,default=2026)
    p.add_argument('--confidence',type=float,default=.3);p.add_argument('--iou',type=float,default=.5)
    p.add_argument('--ap-floor',type=float,default=.001);a=p.parse_args()
    records=json.loads(Path(a.predictions).read_text());out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    primary, outcomes=summarize(records,a.confidence,a.iou,a.ap_floor)
    primary['predictions_sha256']=sha256(a.predictions)
    write_json(out/'summary.json',primary);write_json(out/'matching_records.json',outcomes)
    sweep=[]
    for threshold in [.1,.2,.3,.4,.5,.6,.7]:
        item,_=summarize(records,threshold,a.iou,a.ap_floor)
        sweep.append({k:item[k] for k in ['confidence','GT','TP','FP','FN','precision','recall','f1']})
    write_json(out/'threshold_sweep.json',sweep)
    sensitivity,_=summarize(records,a.confidence,a.iou,a.ap_floor,True,.5)
    write_json(out/'nms_sensitivity.json',sensitivity)
    if a.bootstrap:write_json(out/'bootstrap.json',bootstrap(records,a.bootstrap,a.bootstrap_seed,a.confidence,a.iou,a.ap_floor))
    print('Record-derived analysis exported:',out)


if __name__=='__main__':main()
