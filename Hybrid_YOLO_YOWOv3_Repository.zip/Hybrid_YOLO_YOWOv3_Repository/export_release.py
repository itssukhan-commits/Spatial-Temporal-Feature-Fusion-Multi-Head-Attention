"""Separate source and real execution artifacts with SHA-256 manifests."""
import argparse
import zipfile
from pathlib import Path
from runtime import sha256,write_json


def archive(paths,base,target):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,p.relative_to(base))


def main():
    p=argparse.ArgumentParser();p.add_argument('--repository',default='.');p.add_argument('--runs',default='runs');p.add_argument('--output',default='release')
    a=p.parse_args();root=Path(a.repository).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
    source=[]
    for path in root.rglob('*'):
        if not path.is_file():continue
        relative=path.relative_to(root)
        if any(x in relative.parts for x in ['__pycache__','.git','runs','ucfcrime2local','release','.ipynb_checkpoints']):continue
        if path.is_relative_to(out):continue
        if path.suffix in ['.py','.md','.yaml','.yml','.json','.txt','.cff','.ipynb'] or path.name=='.gitignore':source.append(path)
    write_json(out/'source_sha256.json',{str(p.relative_to(root)):sha256(p) for p in source})
    archive(source,root,out/'repository_source.zip')
    runs=Path(a.runs).resolve()
    if runs.exists():
        actual=[p for p in runs.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
        if actual:
            write_json(out/'run_sha256.json',{str(p.relative_to(runs)):sha256(p) for p in actual})
            archive(actual,runs,out/'experimental_records.zip')
    print('Release exported:',out)


if __name__=='__main__':main()
