# Third-party attribution and licensing

Ultralytics YOLO: https://github.com/ultralytics/ultralytics
Licensing: https://www.ultralytics.com/license
The upstream project offers AGPL-3.0 and enterprise licensing. Retain upstream
notices and select a compatible public release license according to the rights
held by the authors. This package does not assert ownership of upstream code or
assign a license to pretrained weights or dataset bytes.

Torchvision R3D-18: https://pytorch.org/vision/stable/models/generated/torchvision.models.video.r3d_18.html
PyTorch/Torchvision licensing follows the upstream projects.

UCF-Crime2Local: Landi, F.; Snoek, C. G. M.; Cucchiara, R. Anomaly Locality in
Video Surveillance. arXiv:1901.10364, 2019.
The original provider's terms apply independently to dataset redistribution.

The authors should add the final code license and license text before a public
release. The repository preparation does not invent an approval or license grant.
