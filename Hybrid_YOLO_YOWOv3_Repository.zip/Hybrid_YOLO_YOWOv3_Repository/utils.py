"""
Shared utilities: box IoU, reproducibility, checkpoint I/O.
"""
import os
import random
import numpy as np
import torch


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def box_iou_xywh(box1: torch.Tensor, box2: torch.Tensor) -> torch.Tensor:
    """
    Vectorized IoU between two sets of boxes in (cx, cy, w, h) format.
    box1: [N, 4], box2: [M, 4] -> returns [N, M] IoU matrix.
    """
    def to_xyxy(b):
        cx, cy, w, h = b.unbind(-1)
        return torch.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], dim=-1)

    b1 = to_xyxy(box1)  # [N,4]
    b2 = to_xyxy(box2)  # [M,4]

    area1 = (b1[:, 2] - b1[:, 0]).clamp(min=0) * (b1[:, 3] - b1[:, 1]).clamp(min=0)
    area2 = (b2[:, 2] - b2[:, 0]).clamp(min=0) * (b2[:, 3] - b2[:, 1]).clamp(min=0)

    lt = torch.max(b1[:, None, :2], b2[None, :, :2])   # [N,M,2]
    rb = torch.min(b1[:, None, 2:], b2[None, :, 2:])   # [N,M,2]
    wh = (rb - lt).clamp(min=0)
    inter = wh[..., 0] * wh[..., 1]

    union = area1[:, None] + area2[None, :] - inter
    return inter / union.clamp(min=1e-7)


def save_checkpoint(state: dict, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(state, path)


def load_checkpoint(path: str, map_location="cpu") -> dict:
    return torch.load(path, map_location=map_location)


def count_parameters(model: torch.nn.Module) -> float:
    """Returns parameter count in millions, matching the 'Params (M)' column in Table 2/6."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
